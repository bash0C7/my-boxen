# Kobito Puppet Module for Boxen

[Kobito](http://kobito.qiita.com/) for Boxen.

## Usage

```puppet
include kobito
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
